<?php

namespace App\Classes\hybridauth\srcTest\Hybridauth;

use App\Classes\hybridauth\src\Hybridauth;

class HybridauthTest extends \PHPUnit\Framework\TestCase
{
    public function test_pass()
    {
        $this->assertTrue(true);
    }
}
